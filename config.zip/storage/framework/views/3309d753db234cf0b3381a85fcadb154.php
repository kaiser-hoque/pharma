
<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-8">
            <div class="card mt-4">
                <div class="card-body p-4">
                    <h5 class="mb-4">Horizontal Icon</h5>
                     <div class="card-content">
                        <div class="card-body">
                            <form class="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('user.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="roleId">Role  <i class="text-danger">*</i></label>
                                            <select class="form-control" name="roleId" id="roleId">
                                                <option value="">Select Role</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($r->id); ?>" <?php echo e(old('roleId')==$r->id?"selected":""); ?>> <?php echo e($r->type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="">No Role found</option>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('roleId')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('roleId')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                     
                                </div>
                                <div class="row">  
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="password">Password <i class="text-danger">*</i></label>
                                            <input type="password" id="password" class="form-control" name="password">
                                                <?php if($errors->has('password')): ?>
                                                    <span class="text-danger"> <?php echo e($errors->first('password')); ?></span>
                                                <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="image">Image</label>
                                            <input type="file" id="image" class="form-control" placeholder="Image" name="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/medicineType/create.blade.php ENDPATH**/ ?>