<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('page',trans('Create')); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-8">
            <div class="card mt-4">
                <div class="card-body p-4">
                    <h5 class="mb-4">Create Role</h5>
                     <div class="card-content">
                        <div class="card-body">
                           <form class="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('role.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="Identity">Identity (only Alpha Character)<i class="text-danger">*</i></label>
                                    <input type="text" id="Identity" pattern="[A-Za-z]+" class="form-control" value="<?php echo e(old('Identity')); ?>" name="Identity">
                                    <?php if($errors->has('Identity')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('Identity')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="Name">Name</label>
                                    <input type="text" id="Name" class="form-control" value="<?php echo e(old('Name')); ?>" name="Name">
                                    <?php if($errors->has('Name')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('Name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary mt-1 me-1 mb-1">Save</button>
                                
                            </div>
                        </div>
                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/role/create.blade.php ENDPATH**/ ?>