<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('content'); ?>



	<!--wrapper-->
	<div class="wrapper">
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Companies</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Companies Create</li>
							</ol>
						</nav>
					</div>
					 
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-6 mx-auto">
						<div class="card">
							<div class="card-header px-4 py-3">
								<h5 class="mb-0">Companies Create</h5>
							</div>
							<div class="card-body p-4">
								<form method="post" enctype="multipart/form-data" action="<?php echo e(route('companies.store')); ?>" class="row g-3 needs-validation" novalidate>
                                    <?php echo csrf_field(); ?>
									<div class="col-md-12">
										<label for="bsValidation1" class="form-label"><b>Full Name</b></label>
										<input type="text" class="form-control"
										name="name" id="name" placeholder="  Name" >

                                        <?php if($errors->has('name')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
									</div>

									<div class="col-md-12">
										<label for="bsValidation3" class="form-label"><b>Contact Num</b></label>
										<input type="text" class="form-control" id="contact_num"
										name="contact_num"placeholder="contact_num"  >

                                        <?php if($errors->has('contact_num')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('contact_num')); ?></span>
                                    <?php endif; ?>

									</div>
									<div class="col-md-12">
										<label for="bsValidation4" class="form-label"><b>Email</b></label>
										<input type="email" class="form-control"
										name="email" id="email" placeholder="Email" >

                                        <?php if($errors->has('email')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
									</div>

									<div class="sm-col-12">
                                        <div class="form-group">
                                            <label for="status"><b>Status</b></label>
                                            <select id="status" class="form-control" name="status">
                                                <option value="1" <?php if(old('status')==1): ?> selected <?php endif; ?>>Active</option>
                                                <option value="0" <?php if(old('status')==0): ?> selected <?php endif; ?>>Inactive</option>
                                            </select>

                                            <?php if($errors->has('status')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
									<div class="col-md-12">
                                        <div class="form-group">
                                            <label for="division"><b>Division</b></label>
                                            <select id="division" class="form-control" name="division">
												<option value="">select</option>
                                                <option value="Dhaka" <?php if(old('division') == 'Dhaka'): ?> selected <?php endif; ?>>Dhaka</option>
                                                <option value="Chittagong" <?php if(old('division') == 'Chittagong'): ?> selected <?php endif; ?>>Chittagong</option>
                                                <option value="Rajshahi" <?php if(old('division') == 'Rajshahi'): ?> selected <?php endif; ?>>Rajshahi</option>
                                                <option value="Khulna" <?php if(old('division') == 'Khulna'): ?> selected <?php endif; ?>>Khulna</option>
                                                <option value="Barisal" <?php if(old('division') == 'Barisal'): ?> selected <?php endif; ?>>Barisal</option>
                                                <option value="Sylhet" <?php if(old('division') == 'Sylhet'): ?> selected <?php endif; ?>>Sylhet</option>
                                                <option value="Rangpur" <?php if(old('division') == 'Rangpur'): ?> selected <?php endif; ?>>Rangpur</option>
                                            </select>

                                            <?php if($errors->has('division')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('division')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>




									<div class="col-md-12">
										<label for="bsValidation13" class="form-label"><b>Adress</b></label>
										<textarea class="form-control" id="address"
										name="address"placeholder="Address ..." rows="3" ></textarea>

                                        <?php if($errors->has('address')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
									</div>
									<div class="col-md-12">
										<label for="bsValidation13" class="form-label"><b>Description</b></label>
										<textarea class="form-control" id="description" placeholder="description ..."
										name="description"rows="3" required></textarea>

                                        <?php if($errors->has('description')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
									</div>

									<div class="col-md-12">
										<div class="d-md-flex d-grid align-items-center gap-3">
											<button type="submit" class="btn btn-primary px-4">Submit</button>
											<button type="reset" class="btn btn-light px-4">Reset</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/companies/create.blade.php ENDPATH**/ ?>