<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<link rel="icon" href="<?php echo e(asset('public/assets/images/favicon-32x32.png')); ?>" type="image/png"/>
	<!--plugins-->
	<link href="<?php echo e(asset('public/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet"/>
	<link href="<?php echo e(asset('public/assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('public/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('public/assets/plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet"/>
	<link href="<?php echo e(asset('public/assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>" rel="stylesheet" />
	<!-- loader-->
	<link href="<?php echo e(asset('public/assets/css/pace.min.css')); ?>" rel="stylesheet"/>
	<script src="<?php echo e(asset('public/assets/js/pace.min.js')); ?>"></script>
	<!-- Bootstrap CSS -->
	<link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/assets/css/bootstrap-extended.css')); ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">
	<link href="<?php echo e(asset('public/assets/css/app.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('public/assets/css/icons.css')); ?>" rel="stylesheet">
	<!-- Theme Style CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/dark-theme.css')); ?>"/>
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/semi-dark.css')); ?>"/>
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/header-colors.css')); ?>"/>
	<title><?php echo e(env('APP_NAME')); ?> | <?php echo $__env->yieldContent('title','Page Name'); ?></title>
</head>

<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
		<!--start header -->
		 
    <!-- end search modal -->

	<!-- Bootstrap JS -->
	<script src="<?php echo e(asset('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>
	<!--plugins-->
	<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('public/assets/js/index.js')); ?>"></script>
	<!--app JS-->
	<script src="<?php echo e(asset('public/assets/js/app.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" ></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css"/>

	<!-- <script >
			<?php if(Session:: has('success ')): ?>
		toastr.success("<?php echo e(Session:: get('success')); ?>");
		<?php endif; ?>
		<?php if(Session:: has('info ')): ?>
		toastr.info("<?php echo e(Session:: get('info')); ?>");
		<?php endif; ?>
		<?php if(Session:: has('warning ')): ?>
		toastr.warning("<?php echo e(Session:: get('warning')); ?>");
		<?php endif; ?>
		<?php if(Session:: has('error ')): ?>
		toastr.error("<?php echo e(Session:: get('error')); ?>");
		<?php endif; ?>  
	</script> -->
</body>


<!-- Mirrored from codervent.com/syndron/demo/vertical/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 29 Jul 2023 03:55:08 GMT -->
</html><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/layouts/appAuth.blade.php ENDPATH**/ ?>