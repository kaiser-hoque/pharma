<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('content'); ?>



	<!--wrapper-->
	<div class="wrapper">
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Customer</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Customer Edit</li>
							</ol>
						</nav>
					</div>

				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-md-10 mx-auto">
						<div class="card">
							<div class="card-header px-4 py-3">
								<h5 class="mb-0">Customer Edit</h5>
							</div>
							<div class="card-body p-4">
                                <form class="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('customer.update',encryptor('encrypt',$customer->id))); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="row">
									<div class="col-md-5">
										<label for="bsValidation1" class="form-label"><b>Full Name</b></label>
										<input type="text" class="form-control rounded-5"
										name="name" id="name" placeholder="  Name" value="<?php echo e(old('FullName',$customer->name)); ?>" >

                                        <?php if($errors->has('name')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
									</div>

									<div class="col-md-5">
										<label for="bsValidation3" class="form-label"><b>Contact Num</b></label>
										<input type="text" class="form-control rounded-5" id="contact_num"
										name="contact_num"placeholder="contact_num" value="<?php echo e(old('ContactNum',$customer->contact_num)); ?>" >

                                        <?php if($errors->has('contact_num')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('contact_num')); ?></span>
                                    <?php endif; ?>

									</div>
									<div class="col-md-5">
										<label for="bsValidation4" class="form-label"><b>Email</b></label>
										<input type="email" class="form-control rounded-5"
										name="email" id="email" placeholder="Email" value="<?php echo e(old('Email',$customer->email)); ?>" >

                                        <?php if($errors->has('email')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
									</div>

                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="status"><b>Gender</b></label>
                                            <select id="gender" class="form-control" name="gender">
                                                <option value="male" <?php if(old('gender')=='male'): ?> selected <?php endif; ?>>Male</option>
                                                <option value="female" <?php if(old('gender')=='female'): ?> selected <?php endif; ?>>Female</option>
                                            </select>

                                            <?php if($errors->has('gender')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('gender')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>


									 <div class="col-md-5">
                                        <div class="form-group">
                                            <label for="status"><b>Status</b></label>
                                            <select id="status" class="form-control" name="status">
                                                <option value="1" <?php if(old('status')==1): ?> selected <?php endif; ?>>Active</option>
                                                <option value="0" <?php if(old('status')==0): ?> selected <?php endif; ?>>Inactive</option>
                                            </select>

                                            <?php if($errors->has('status')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>


									<div class="col-md-5">
										<label for="bsValidation13" class="form-label"><b>Adress</b></label>
										<textarea class="form-control rounded-5" id="address"
										name="address"placeholder="Address ..." rows="3" value="<?php echo e(old('Adress',$customer->address)); ?>" ></textarea>

                                        <?php if($errors->has('address')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
									</div>
									<div class="col-md-5">
										<label for="bsValidation13" class="form-label"><b>Description</b></label>
										<textarea class="form-control rounded-5" id="description" placeholder="description ..."
										name="description"rows="3" value="<?php echo e(old('Description',$customer->description)); ?>" ></textarea>

                                        <?php if($errors->has('description')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('description')); ?></span>
                                    <?php endif; ?>
									</div>

									<div class="col-md-12">
										<div class="d-md-flex d-grid align-items-center gap-3">
											<button type="submit" class="btn btn-primary px-4">Submit</button>
											<button type="reset" class="btn btn-light px-4">Reset</button>
										</div>
									</div>
                                </div>
								</form>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/customer/edit.blade.php ENDPATH**/ ?>