<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('page',trans('Create')); ?>
<?php $__env->startSection('content'); ?>
	<div class="wrapper">
        <div class="page-wrapper">
			<div class="page-content">
				<div class="card">
					<div class="card-body">
                        <form class="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('category.store')); ?>">
                            <?php echo csrf_field(); ?>
						<div class="row row-cols-1 g-3 row-cols-lg-auto align-items-center">
						   <div class="col">
                            <label for="category"> <h4>Add Category</h4></label>
							    <input type="text" class="form-control" id="category_name"
                                name="category_name" placeholder="category name">

                                <?php if($errors ->has ('category_name')): ?>
                                <span class="text-danger"
                                ><?php echo e($errors-first ('category_name')); ?></span>
                                <?php endif; ?>

							    <button type="submit" class="btn btn-primary mt-4">Submit</button>
						 </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="overlay toggle-icon"></div>
		<a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>

		<footer class="page-footer">
			<p class="mb-0">
                Copyright © 2023. All right reserved.</p>
		</footer>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/category/create.blade.php ENDPATH**/ ?>