<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('content'); ?>






	<div class="page-wrapper">
			<div class="page-content">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center">
							<div>
								<h5 class="mb-0">User Name</h5>
							</div>
							<div class="font-22 ms-auto"><i class='bx bx-dots-horizontal-rounded'></i>
							</div>
						</div>
						<div class="d-lg-flex align-items-center mb-4 gap-3">
							<div class="position-relative">
								<input type="text" class="form-control ps-5 radius-30" placeholder="Search Order"> <span class="position-absolute top-50 product-show translate-middle-y"><i class="bx bx-search"></i></span>
							</div>
						  <div class="ms-auto"><a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New User</a></div>
						</div>
						<hr/>
						<div class="table-responsive">
							<table class="table align-middle mb-0">
								<thead class="table-light">
									<tr>
										<th scope="col"><?php echo e(__('#SL')); ?></th>
										<th scope="col"><?php echo e(__('Name')); ?></th>
										<th scope="col"><?php echo e(__('Email')); ?></th>
										<th scope="col"><?php echo e(__('Contact')); ?></th>
										<th scope="col"><?php echo e(__('Role')); ?></th>
										<th scope="col"><?php echo e(__('Image')); ?></th>
										<th scope="col"><?php echo e(__('Status')); ?></th>
										<th class="white-space-nowrap"><?php echo e(__('Action')); ?></th>
									</tr>
								</thead>
								<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="">
                                <td><?php echo e(++$loop->index); ?></td>
                                <td><?php echo e($d->name_en); ?></td>
                                <td><?php echo e($d->email); ?></td>
                                <td><?php echo e($d->contact_no_en); ?></td>
                                
                                <td><?php echo e($d->role?->name); ?></td>
                                <td><img width="50px" class="product-img" src="<?php echo e(asset('public/uploads/users/'.$d->image)); ?>" alt=""></td>
                                <td style="color: <?php if($d->status==1): ?> green <?php else: ?> red <?php endif; ?>; border-radius: 5px;font-weight: bold; font-size:15px"><?php if($d->status==1): ?><?php echo e(__('Active')); ?> <?php else: ?><?php echo e(__('Inactive')); ?> <?php endif; ?></td>
                                <td class="btn group">
                                    <a href="<?php echo e(route('user.edit',encryptor('encrypt',$d->id))); ?>"><i class="fa fa-edit"></i></a>

                                    <form id="" action="<?php echo e(route('user.destroy',encrypt($d->id))); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button style="background: none; border: none;" type="submit"><i class="fa fa-trash text-danger"></i></button>

                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <th colspan="8" class="text-center">No Pruduct Found</th>
                            </tr>
                        <?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
	</div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/user/index.blade.php ENDPATH**/ ?>