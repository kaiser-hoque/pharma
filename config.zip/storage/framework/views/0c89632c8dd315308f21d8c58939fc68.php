

<?php $__env->startSection('pageTitle',trans('Update Users')); ?>
<?php $__env->startSection('pageSubTitle',trans('Update')); ?>

<?php $__env->startSection('content'); ?>
  <!-- // Basic multiple Column Form section start -->
    <section id="multiple-column-form">
        <div class="row match-height">
            <div class="col-12">
                <div class="card">
                    <div class="card-content">
                        <div class="card-body">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-8">
            <div class="card mt-4">
                <div class="card-body p-4">
                    <h5 class="mb-4">Horizontal Icon</h5>
                     <div class="card-content">
                        <div class="card-body">
                            <form class="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('user.update',encryptor('encrypt',$user->id))); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="uptoken" value="<?php echo e(encryptor('encrypt',$user->id)); ?>">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="roleId">Role  <i class="text-danger">*</i></label>
                                            <select class="form-control" name="roleId" id="roleId">
                                                <option value="">Select Role</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($r->id); ?>" <?php echo e(old('roleId',$user->role_id)==$r->id?"selected":""); ?>> <?php echo e($r->type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option value="">No Role found</option>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('roleId')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('roleId')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="userName_en">Name (English) <i class="text-danger">*</i></label>
                                            <input type="text" id="userName_en" class="form-control" value="<?php echo e(old('userName_en',$user->name_en)); ?>" name="userName_en">
                                            <?php if($errors->has('userName_en')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('userName_en')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="userName_bn">Name (Bangla)</label>
                                            <input type="text" id="userName_bn" class="form-control" value="<?php echo e(old('userName_bn',$user->name_bn)); ?>" name="userName_bn">
                                            <?php if($errors->has('userName_bn')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('userName_bn')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="EmailAddress">Email <i class="text-danger">*</i></label>
                                            <input type="text" id="EmailAddress" class="form-control" value="<?php echo e(old('EmailAddress',$user->email)); ?>" name="EmailAddress">
                                            <?php if($errors->has('EmailAddress')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('EmailAddress')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="contactNumber_en">Contact Number (English) <i class="text-danger">*</i></label>
                                            <input type="text" id="contactNumber_en" class="form-control" value="<?php echo e(old('contactNumber_en',$user->contact_no_en)); ?>" name="contactNumber_en">
                                            <?php if($errors->has('contactNumber_en')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('contactNumber_en')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="contactNumber_bn">Contact Number (Bangla)</label>
                                            <input type="text" id="contactNumber_bn" class="form-control" value="<?php echo e(old('contactNumber_bn',$user->contact_no_bn)); ?>" name="contactNumber_bn">
                                            <?php if($errors->has('contactNumber_bn')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('contactNumber_bn')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select id="status" class="form-control" name="status">
                                                <option value="1" <?php if(old('status',$user->status)==1): ?> selected <?php endif; ?>>Active</option>
                                                <option value="0" <?php if(old('status',$user->status)==0): ?> selected <?php endif; ?>>Inactive</option>
                                            </select>
                                            <?php if($errors->has('status')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="fullAccess">Full Access</label>
                                            <select id="fullAccess" class="form-control" name="fullAccess">
                                                <option value="0" <?php if(old('fullAccess',$user->full_access)==0): ?> selected <?php endif; ?>>No</option>
                                                <option value="1" <?php if(old('fullAccess',$user->full_access)==1): ?> selected <?php endif; ?>>Yes</option>
                                            </select>
                                            <?php if($errors->has('fullAccess')): ?>
                                                <span class="text-danger"> <?php echo e($errors->first('fullAccess')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">  
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="password">Password <i class="text-danger">*</i></label>
                                            <input type="password" id="password" class="form-control" name="password">
                                                <?php if($errors->has('password')): ?>
                                                    <span class="text-danger"> <?php echo e($errors->first('password')); ?></span>
                                                <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="image">Image</label>
                                            <input type="file" id="image" class="form-control" placeholder="Image" name="image">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/user/edit.blade.php ENDPATH**/ ?>