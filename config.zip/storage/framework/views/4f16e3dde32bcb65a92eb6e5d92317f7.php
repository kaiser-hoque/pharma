 





 
 <?php $__env->startSection('title',trans('create Users')); ?>
 <?php $__env->startSection('content'); ?>






 <div class="page-wrapper">
     <div class="page-content">
         <div class="card radius-10">
             <div class="card-body">
                 
                 <div class="d-lg-flex align-items-center mb-4 gap-3">
                     
                     <div class="ms-auto"><a href="<?php echo e(route('role.create')); ?>"
                             class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New
                             User</a></div>
                 </div>
                 <hr />
                 <div class="table-responsive">
                     <table class="table align-middle mb-0">
                         <thead>
                        <tr>
                            <th scope="col"><?php echo e(__('#SL')); ?></th>
                            <th scope="col"><?php echo e(__('Name')); ?></th>
                            <th scope="col"><?php echo e(__('Identity')); ?></th>
                            <th class="white-space-nowrap"><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e(++$loop->index); ?></th>
                            <td><?php echo e($p->name); ?></td>
                            <td><?php echo e($p->identity); ?></td>
                            <td class="white-space-nowrap">
                                <a href="<?php echo e(route('role.edit',encryptor('encrypt',$p->id))); ?>">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="<?php echo e(route('permission.list',encryptor('encrypt',$p->id))); ?>">
                                    <i class="fa fa-unlock"></i>
                                </a>
                                <a href="javascript:void()" onclick="$('#form<?php echo e($p->id); ?>').submit()">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <form id="form<?php echo e($p->id); ?>" action="<?php echo e(route('role.destroy',encryptor('encrypt',$p->id))); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th colspan="8" class="text-center">No Pruduct Found</th>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/role/index.blade.php ENDPATH**/ ?>