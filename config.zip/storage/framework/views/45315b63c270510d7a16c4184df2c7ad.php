<?php $__env->startSection('title',trans('Role')); ?>
<?php $__env->startSection('page',trans('Update')); ?>

<?php $__env->startSection('content'); ?>


 <div class="page-wrapper">
     <div class="page-content">
         <div class="card radius-10">
             <div class="card-body">
                 
                 <div class="d-lg-flex align-items-center mb-4 gap-3">


<div class="row">
    
        
                    <form class="form" method="post" action="<?php echo e(route('role.update',encryptor('encrypt',$role->id))); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <input type="hidden" name="uptoken" value="<?php echo e(encryptor('encrypt',$role->id)); ?>">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <label for="Identity">Identity (only Alpha Character)<i class="text-danger">*</i></label>
                                    <input type="text" id="Identity" pattern="[A-Za-z]+" class="form-control" value="<?php echo e(old('Identity',$role->identity)); ?>" name="Identity">
                                    <?php if($errors->has('Identity')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('Identity')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="Name">Name</label>
                                    <input type="text" id="Name" class="form-control" value="<?php echo e(old('Name',$role->name)); ?>" name="Name">
                                    <?php if($errors->has('Name')): ?>
                                        <span class="text-danger"> <?php echo e($errors->first('Name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                
                            </div>
                        </div>
                    </form>
                
     
</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/role/edit.blade.php ENDPATH**/ ?>