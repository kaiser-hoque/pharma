<?php $__env->startSection('title', trans('create Users')); ?>
<?php $__env->startSection('content'); ?>




    <div class="wrapper">
        <div class="page-wrapper">
            <div class="page-content">
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">Customer</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Customer Data List</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="ms-auto">
                        <div class="btn-group">
                            <div class="ms-auto"><a href="<?php echo e(route('customer.create')); ?>"
                                    class="btn btn-primary radius-30 mt-2 mt-lg-0"><i class="bx bxs-plus-square"></i>Add New
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <h6 class="mb-0 text-uppercase">Customer List</h6>
                <hr />
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('SL')); ?></th>
                                        <th><?php echo e(__('Name')); ?></th>
                                        <th><?php echo e(__('Contact NO')); ?></th>
                                        <th><?php echo e(__('Email')); ?></th>
                                        <th><?php echo e(__('Gender')); ?></th>
                                        <th><?php echo e(__('Address')); ?></th>
                                        <th><?php echo e(__('Starus')); ?></th>
                                        <th><?php echo e(__('Description')); ?></th>
                                        <th class="white-space-nowrap"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e(++$loop->index); ?></td>
                                        <td class="text-center"><?php echo e($value->name); ?></td>
                                        <td class="text-center"><?php echo e($value->contact_num); ?></td>
                                        <td class="text-center"><?php echo e($value->email); ?></td>
                                        <td class="text-center"><?php echo e($value->gender); ?></td>
                                        <td class="text-center"><?php echo e($value->address); ?></td>
                                        <td class="text-center"><?php echo e($value->status); ?></td>
                                        <td class="text-center"><?php echo e($value->description); ?></td>
                                        <td class="action-buttons">
                                            <div class="button-container">
                                                <a href="<?php echo e(route('customer.edit', 		encryptor('encrypt', $value->id))); ?>">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <form id="" action="<?php echo e(route('customer.destroy', encrypt($value->id))); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button style="background: none; border: none;" type="submit">
                                                        <i class="fa fa-trash text-danger"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th colspan="8" class="text-center">No Product Found</th>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            
            <style>
                .action-buttons {
                    width: 1%;
                    white-space: nowrap;
                }

                .button-container {
                    display: flex;
                    gap: 10px;
                }
            </style>

        </div>


        <div class="overlay toggle-icon"></div>
        <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
        <footer class="page-footer">
            <p class="mb-0">Copyright © 2023. All right reserved.</p>
        </footer>
    </div>




    </div>
    <?php $__env->startPush('scripts'); ?>
        ;
        <script>
            $(document).ready(function() {
                $('#example').DataTable();
            });
        </script>
        <script>
            $(document).ready(function() {
                var table = $('#example2').DataTable({
                    lengthChange: false,
                    buttons: ['copy', 'excel', 'pdf', 'print']
                });

                table.buttons().container()
                    .appendTo('#example2_wrapper .col-md-6:eq(0)');
            });
        </script>
    <?php $__env->stopPush(); ?>

    <!--app JS-->
    <script src="assets/js/app.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/attendances/index.blade.php ENDPATH**/ ?>