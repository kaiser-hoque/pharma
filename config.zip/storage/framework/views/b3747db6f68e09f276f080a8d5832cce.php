 







<?php $__env->startSection('title',trans('create Users')); ?>
<?php $__env->startSection('content'); ?>

 

 


	<div class="page-wrapper">
			<div class="page-content">
				<div class="card radius-10">
					 <div class="row">
    <div class="col-8 mx-3">
         
            <h4><?php echo e($role->type); ?></h4>
            <?php 
                $routes=array();
                $auto_accept=array('GET',"DELETE");
                $permissions=array();
                foreach($permission as $perm){
                    $permissions[$perm->name]=$perm->name;
                }
            ?>
            <?php $__currentLoopData = Illuminate\Support\Facades\Route::getRoutes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($v->getPrefix()=="/admin"): ?>
                    <?php
                        $rl=explode('.',$v->getName());
                        if(isset($rl[1]))
                            $routes[$rl[0]][]=array("method"=>$v->methods[0],"function"=>$rl[1]);
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('permission.save',encryptor('encrypt',$role->id))); ?>" method="post">
                <?php echo csrf_field(); ?>
            
                <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-6 col-sm-3 col-md-3 mt-3">
                        <input type="checkbox" onchange="checkAll(this)"> <?php echo e(__($k)); ?>

                        <?php if($r): ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($name['method'],$auto_accept)): ?>
                                    <li class="list-group-item">
                                        <?php if(in_array($k.'.'.$name['function'],$permissions)): ?>
                                            <input type="checkbox"  checked name="permission[]" value="<?php echo e($k.'.'.$name['function']); ?>"> 
                                             <?php echo e(__($name['function'])); ?> 
                                        <?php else: ?>
                                        <input type="checkbox" name="permission[]" value="<?php echo e($k.'.'.$name['function']); ?>"> <?php echo e(__($name['function'])); ?>

                                        <?php endif; ?>
                                    </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-12 mt-2 mb-2">
                        <button type="submit" class="btn btn-primary"> Save</button>
                    </div>
                </div>
            </form>
            
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function checkAll(e){
        if($(e).prop('checked')==true)
            $(e).next('.list-group').find('input').attr('checked','checked');
        else
            $(e).next('.list-group').find('input').removeAttr('checked','checked');
    }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Safayet Round_54\PHP MYSQL\htdocs\pharma\resources\views/backend/permission/index.blade.php ENDPATH**/ ?>